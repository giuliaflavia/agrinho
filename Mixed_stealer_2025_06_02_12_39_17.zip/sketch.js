// Variáveis do jogador
let player;
let bullets = [];
let enemies = [];
let enemySpeed = 2;
let bulletSpeed = 5;

function setup() {
  createCanvas(400, 600);
  player = new Player();
}

function draw() {
  background(0);

  // Atualiza e desenha o jogador
  player.update();
  player.display();

  // Cria inimigos
  if (frameCount % 60 === 0) {
    enemies.push(new Enemy());
  }

  // Atualiza e desenha os inimigos
  for (let i = enemies.length - 1; i >= 0; i--) {
    enemies[i].update();
    enemies[i].display();

    // Verifica colisão com o jogador
    if (enemies[i].hits(player)) {
      noLoop(); // Para o jogo
      textSize(32);
      textAlign(CENTER, CENTER);
      fill(255);
      text("Game Over!", width / 2, height / 2);
    }

    // Remove inimigos que saem da tela
    if (enemies[i].y > height) {
      enemies.splice(i, 1);
    }
  }

  // Atualiza e desenha os tiros
  for (let i = bullets.length - 1; i >= 0; i--) {
    bullets[i].update();
    bullets[i].display();

    // Verifica se o tiro acertou um inimigo
    for (let j = enemies.length - 1; j >= 0; j--) {
      if (bullets[i].hits(enemies[j])) {
        enemies.splice(j, 1);
        bullets.splice(i, 1);
        break;
      }
    }

    // Remove tiros que saem da tela
    if (bullets[i].y < 0) {
      bullets.splice(i, 1);
    }
  }
}

// Classe do jogador
class Player {
  constructor() {
    this.x = width / 2;
    this.y = height - 30;
    this.size = 30;
    this.speed = 5;
  }

  update() {
    // Controle do jogador (movimento)
    if (keyIsDown(LEFT_ARROW) && this.x > 0) {
      this.x -= this.speed;
    }
    if (keyIsDown(RIGHT_ARROW) && this.x < width - this.size) {
      this.x += this.speed;
    }

    // Atirar com a tecla "Space"
    if (keyIsPressed && key === ' ') {
      this.shoot();
    }
  }

  display() {
    fill(0, 0, 255);
    noStroke();
    ellipse(this.x, this.y, this.size, this.size);
  }

  shoot() {
    // Cria um novo tiro e adiciona ao array de tiros
    bullets.push(new Bullet(this.x, this.y - this.size / 2));
  }
}

// Classe do tiro
class Bullet {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 10;
  }

  update() {
    // Movimento do tiro (vai para cima)
    this.y -= bulletSpeed;
  }

  display() {
    fill(255, 255, 0);
    noStroke();
    ellipse(this.x, this.y, this.size, this.size);
  }

  hits(enemy) {
    // Verifica se o tiro acertou o inimigo
    let d = dist(this.x, this.y, enemy.x, enemy.y);
    return d < this.size / 2 + enemy.size / 2;
  }
}

// Classe do inimigo
class Enemy {
  constructor() {
    this.x = random(0, width - 30);
    this.y = -30;
    this.size = 30;
    this.speed = enemySpeed;
  }

  update() {
    // Movimento do inimigo (desce para baixo)
    this.y += this.speed;
  }

  display() {
    fill(255, 0, 0);
    noStroke();
    rect(this.x, this.y, this.size, this.size);
  }

  hits(player) {
    // Verifica colisão com o jogador
    let d = dist(this.x + this.size / 2, this.y + this.size / 2, player.x, player.y);
    return d < this.size / 2 + player.size / 2;
  }
}
   